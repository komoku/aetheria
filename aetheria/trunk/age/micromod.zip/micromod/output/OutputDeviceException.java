
package micromod.output;

/**
	General output device exception.
*/
public class OutputDeviceException extends Exception {
	public OutputDeviceException( String msg ){
		super(msg);
	}
}
